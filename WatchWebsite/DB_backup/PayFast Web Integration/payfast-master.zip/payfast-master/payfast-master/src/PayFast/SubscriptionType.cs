﻿namespace PayFast
{
    public enum SubscriptionType
    {
        Subscription = 1,
        AdHoc = 2
    }
}
