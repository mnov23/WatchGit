﻿namespace PayFast.ApiTypes
{
    public class AdhocData
    {
        public string response { get; set; }
        public string message { get; set; }
    }
}
