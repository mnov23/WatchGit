﻿namespace PayFast.ApiTypes
{
    public class GenericData<T>
    {
        public T response { get; set; }
    }
}
