﻿namespace PayFast.ApiTypes
{
    using PayFast.Base;

    public class AdhocResult : ApiResultBase
    {
        public AdhocData data { get; set; }
    }
}
