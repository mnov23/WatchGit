﻿namespace PayFast.ApiTypes
{
    using PayFast.Base;

    public class AdhocCancelResult : ApiResultBase
    {
        public AdhocData data { get; set; }
    }
}
