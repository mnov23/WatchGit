﻿namespace PayFast
{
    public enum BillingFrequency
    {
        Monthly = 3,
        Quarterly = 4,
        Biannual = 5,
        Annual = 6
    }
}
