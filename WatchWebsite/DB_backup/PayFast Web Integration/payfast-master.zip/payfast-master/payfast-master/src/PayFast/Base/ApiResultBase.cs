﻿namespace PayFast.Base
{
    public class ApiResultBase
    {
        #region Properties

        public string code { get; set; }
        public string status { get; set; }

        #endregion Properties
    }
}
