﻿namespace PayFast.ApiTypes
{
    using PayFast.Base;

    public class AdhocFetchResult : ApiResultBase
    {
        public FetchData data { get; set; }
    }
}
