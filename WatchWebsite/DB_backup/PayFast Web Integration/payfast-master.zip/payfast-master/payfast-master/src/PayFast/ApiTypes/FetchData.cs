﻿namespace PayFast.ApiTypes
{
    public class FetchData
    {
        public FetchResponse response { get; set; }
    }
}
